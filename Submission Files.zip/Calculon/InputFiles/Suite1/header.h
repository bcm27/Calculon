#ifndef _HEADER_H_INCLUDED
#define _HEADER_H_INCLUDED

#define BUFFER_SIZE 1000

#endif
