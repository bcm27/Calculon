My directory is set up as follows:
All name.c and associated header files are located within: Calculon/workingDirectory/allFiles

To compile the program I used: ggc main.c debugger.c dataTypes.c suiteHandler.c testHandler.c fileHandler.c -o Calculon

I then moved the Calculon executable down two directories into the Calculon parent directory. Execution of the shell script
with the following command arguments works in according to the requirments: ./shellscript Suite<1-8>

An additional argument of -d will print out the debugging information: ./shellscript Suite<1-8> -d

Please read the shell script for information on how files are transferred into the /workingDirectory/testingEnvironment/

Thank you for an enjoyable and hard semester once again Clint. Its been fun I will see you in the final tomorrow.

~Bjorn Mathisen

