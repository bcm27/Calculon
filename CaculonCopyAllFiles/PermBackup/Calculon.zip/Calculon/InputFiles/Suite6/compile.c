This is not a valid c program and will never compile!;
<^$>&#;
++'';
{}{}{}{}{
