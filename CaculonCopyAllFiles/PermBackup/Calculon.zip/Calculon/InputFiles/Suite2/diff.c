#include <stdio.h>

int main()
{
	printf("Blah blah blah\n");
	return 0;
}
