int main()
{
	char * foo = 0;
	while (1)
		*foo++ = 0xFF;
	return 0;
}