int main()
{
	int x = 0;
	while (1)
		x = x + x * x * x + x * x + x * x * x * x;
	return 0;
}
